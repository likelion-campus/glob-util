# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['glob_util', 'glob_util.domains', 'glob_util.repositories']

package_data = \
{'': ['*']}

install_requires = \
['voluptuous>=0.12.1,<0.13.0']

setup_kwargs = {
    'name': 'glob-util',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'hanvic',
    'author_email': 'hanvic@likelion.net',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
